/* ═══════════════════════════════════════════
   PURE FOR CURE — main.js
═══════════════════════════════════════════ */

document.addEventListener('DOMContentLoaded', () => {

  /* ─── LOADER ─── */
  const loader = document.getElementById('loader');
  window.addEventListener('load', () => {
    setTimeout(() => loader.classList.add('loaded'), 1600);
  });

  /* ─── PARTICLES ─── */
  const particleContainer = document.getElementById('particles');
  if (particleContainer) {
    for (let i = 0; i < 30; i++) {
      const p = document.createElement('div');
      p.className = 'particle';
      p.style.cssText = `
        left: ${Math.random() * 100}%;
        bottom: ${Math.random() * 20}%;
        width: ${2 + Math.random() * 4}px;
        height: ${2 + Math.random() * 4}px;
        animation-duration: ${6 + Math.random() * 12}s;
        animation-delay: ${Math.random() * 8}s;
        opacity: ${0.2 + Math.random() * 0.5};
      `;
      particleContainer.appendChild(p);
    }
  }

  /* ─── NAVBAR SCROLL ─── */
  const navbar = document.getElementById('navbar');
  const backToTop = document.getElementById('backToTop');
  window.addEventListener('scroll', () => {
    if (window.scrollY > 60) {
      navbar.classList.add('scrolled');
      backToTop.classList.add('visible');
    } else {
      navbar.classList.remove('scrolled');
      backToTop.classList.remove('visible');
    }
  }, { passive: true });

  /* ─── MOBILE NAV ─── */
  const hamburger = document.querySelector('.nav-hamburger');
  const mobileNav = document.querySelector('.nav-mobile');
  hamburger?.addEventListener('click', () => {
    hamburger.classList.toggle('open');
    mobileNav.classList.toggle('open');
  });
  document.querySelectorAll('.nav-mobile a').forEach(link => {
    link.addEventListener('click', () => {
      hamburger.classList.remove('open');
      mobileNav.classList.remove('open');
    });
  });

  /* ─── BACK TO TOP ─── */
  backToTop?.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  /* ─── SMOOTH SCROLL for nav links ─── */
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', e => {
      const target = document.querySelector(anchor.getAttribute('href'));
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

  /* ─── SCROLL REVEAL ─── */
  const revealEls = document.querySelectorAll('.reveal-up, .reveal-left, .reveal-right');
  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
  revealEls.forEach(el => revealObserver.observe(el));

  /* ─── COUNTER ANIMATION ─── */
  function animateCounter(el, target, duration = 2000) {
    const start = performance.now();
    const update = (now) => {
      const elapsed = now - start;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      el.textContent = Math.floor(eased * target).toLocaleString('en-IN');
      if (progress < 1) requestAnimationFrame(update);
      else el.textContent = target.toLocaleString('en-IN');
    };
    requestAnimationFrame(update);
  }

  const counterEls = document.querySelectorAll('.stat-number, .hstat-num');
  const counterObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const el = entry.target;
        const target = parseInt(el.dataset.target, 10);
        animateCounter(el, target);
        counterObserver.unobserve(el);
      }
    });
  }, { threshold: 0.5 });
  counterEls.forEach(el => counterObserver.observe(el));

  /* ─── MISSION/VISION TABS ─── */
  const tabs = document.querySelectorAll('.mv-tab');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      document.querySelectorAll('.mv-content').forEach(c => c.classList.add('hidden'));
      const target = document.getElementById(`mv-${tab.dataset.tab}`);
      target?.classList.remove('hidden');
    });
  });

  /* ─── TESTIMONIALS CAROUSEL ─── */
  const track = document.getElementById('testimonialsTrack');
  const cards = track?.querySelectorAll('.testimonial-card');
  const dotsContainer = document.getElementById('tDots');
  const prevBtn = document.getElementById('tPrev');
  const nextBtn = document.getElementById('tNext');

  if (track && cards && cards.length) {
    let currentIndex = 0;
    let cardsVisible = 3;
    let autoInterval;

    const getCardsVisible = () => window.innerWidth < 768 ? 1 : window.innerWidth < 1024 ? 2 : 3;
    const totalSlides = () => Math.ceil(cards.length / getCardsVisible());

    const buildDots = () => {
      if (!dotsContainer) return;
      dotsContainer.innerHTML = '';
      for (let i = 0; i < totalSlides(); i++) {
        const dot = document.createElement('div');
        dot.className = `t-dot${i === 0 ? ' active' : ''}`;
        dot.addEventListener('click', () => goTo(i));
        dotsContainer.appendChild(dot);
      }
    };

    const updateDots = () => {
      document.querySelectorAll('.t-dot').forEach((d, i) => {
        d.classList.toggle('active', i === currentIndex);
      });
    };

    const goTo = (index) => {
      cardsVisible = getCardsVisible();
      const max = totalSlides() - 1;
      currentIndex = Math.max(0, Math.min(index, max));
      const cardWidth = cards[0].offsetWidth + 28;
      track.style.transform = `translateX(-${currentIndex * cardsVisible * cardWidth}px)`;
      updateDots();
    };

    prevBtn?.addEventListener('click', () => { goTo(currentIndex - 1); resetAuto(); });
    nextBtn?.addEventListener('click', () => { goTo(currentIndex + 1); resetAuto(); });

    const startAuto = () => {
      autoInterval = setInterval(() => {
        const next = currentIndex + 1 >= totalSlides() ? 0 : currentIndex + 1;
        goTo(next);
      }, 5000);
    };
    const resetAuto = () => { clearInterval(autoInterval); startAuto(); };

    // Touch/swipe support
    let touchStartX = 0;
    track.addEventListener('touchstart', e => { touchStartX = e.touches[0].clientX; }, { passive: true });
    track.addEventListener('touchend', e => {
      const diff = touchStartX - e.changedTouches[0].clientX;
      if (Math.abs(diff) > 40) { diff > 0 ? goTo(currentIndex + 1) : goTo(currentIndex - 1); resetAuto(); }
    });

    window.addEventListener('resize', () => { buildDots(); goTo(0); });

    buildDots();
    startAuto();
  }

  /* ─── GALLERY LIGHTBOX ─── */
  const lightbox = document.getElementById('lightbox');
  const lightboxImg = document.getElementById('lightboxImg');
  document.querySelectorAll('.gallery-item').forEach(item => {
    item.addEventListener('click', () => {
      const img = item.querySelector('img');
      if (img && img.src) {
        lightboxImg.src = img.src;
        lightboxImg.alt = img.alt;
        lightbox.classList.add('open');
        document.body.style.overflow = 'hidden';
      }
    });
  });
  const closeLightbox = () => {
    lightbox.classList.remove('open');
    document.body.style.overflow = '';
  };
  document.querySelector('.lightbox-close')?.addEventListener('click', closeLightbox);
  document.querySelector('.lightbox-overlay')?.addEventListener('click', closeLightbox);
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeLightbox(); });

  /* ─── DONATE AMOUNT BUTTONS ─── */
  document.querySelectorAll('.amount-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.amount-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const customInput = document.getElementById('customAmount');
      if (customInput) customInput.value = btn.dataset.amount;
    });
  });

  /* ─── COPY TO CLIPBOARD ─── */
  document.querySelectorAll('.copy-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const text = btn.dataset.copy;
      try {
        await navigator.clipboard.writeText(text);
        const icon = btn.querySelector('i');
        icon.className = 'fas fa-check';
        btn.style.color = '#4ade80';
        setTimeout(() => {
          icon.className = 'fas fa-copy';
          btn.style.color = '';
        }, 2000);
      } catch {}
    });
  });

  /* ─── VOLUNTEER FORM ─── */
  document.getElementById('volunteerForm')?.addEventListener('submit', e => {
    e.preventDefault();
    const btn = e.target.querySelector('button[type="submit"]');
    const original = btn.innerHTML;
    btn.innerHTML = '<i class="fas fa-check"></i> Registered! We\'ll reach out soon.';
    btn.style.background = '#16a34a';
    e.target.reset();
    setTimeout(() => {
      btn.innerHTML = original;
      btn.style.background = '';
    }, 4000);
  });

  /* ─── CONTACT FORM ─── */
  document.getElementById('contactForm')?.addEventListener('submit', e => {
    e.preventDefault();
    const btn = e.target.querySelector('button[type="submit"]');
    const original = btn.innerHTML;
    btn.innerHTML = '<i class="fas fa-check"></i> Message Sent! Thank you.';
    btn.style.background = '#16a34a';
    e.target.reset();
    setTimeout(() => {
      btn.innerHTML = original;
      btn.style.background = '';
    }, 4000);
  });

  /* ─── ACTIVE NAV LINK on scroll ─── */
  const sections = document.querySelectorAll('section[id]');
  const navLinks = document.querySelectorAll('.nav-links a');
  const sectionObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        navLinks.forEach(link => {
          link.classList.toggle('active', link.getAttribute('href') === `#${entry.target.id}`);
        });
      }
    });
  }, { threshold: 0.4 });
  sections.forEach(s => sectionObserver.observe(s));

  /* ─── HERO PARALLAX ─── */
  window.addEventListener('scroll', () => {
    const scrolled = window.scrollY;
    const hero = document.getElementById('hero');
    if (hero && scrolled < window.innerHeight) {
      hero.querySelector('.hero-content').style.transform = `translateY(${scrolled * 0.2}px)`;
      hero.querySelector('.hero-overlay').style.opacity = 1 - scrolled / window.innerHeight;
    }
  }, { passive: true });

});
